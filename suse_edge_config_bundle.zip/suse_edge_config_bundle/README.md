# SUSE Edge Config Bundle

This bundle contains starter configuration files for a Scale Computing VM-based remote edge deployment using SUSE Edge + Rancher Elemental.

## Files

- `machineregistration.yaml` — Rancher Elemental MachineRegistration for phone-home onboarding
- `eib-config.yaml` — Edge Image Builder configuration for the golden image
- `network/_all.yaml` — default DHCP network config
- `network/static-site-example.yaml` — example static IP config for a site-specific deployment

## Replace before use

In `eib-config.yaml`, replace:

- `<REPLACE_WITH_HASHED_ROOT_PASSWORD>`
- `<REPLACE_WITH_HASHED_EDGEADMIN_PASSWORD>`
- `<REPLACE_WITH_SUSE_REG_CODE>`
- the placeholder SSH public key

## Basic usage

1. Apply MachineRegistration:

```bash
kubectl apply -f machineregistration.yaml
REGISURL=$(kubectl get machineregistration scale-remote-edge -n fleet-default -o jsonpath='{.status.registrationURL}')
```

2. Download Elemental config into your EIB workspace:

```bash
curl "$REGISURL" -o elemental/elemental_config.yaml
```

3. Build the image with EIB.
